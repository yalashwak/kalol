// interactive.js
// Handles client-side form validation for login/signup pages.

function handleSubmit(event) {
            // Get references to form fields and error message
            const errorMessage = document.getElementById('errorMessage');
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            // Prevent form submission if fields are empty
            if (!username || !password) {
                event.preventDefault();
                errorMessage.style.display = 'block';
                return false;
            } else {
                errorMessage.style.display = 'none';
                return true;
            }
        }