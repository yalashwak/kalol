<?php
// remove_friend.php
// Handles removing a friend relationship and any pending friend requests between two users.

session_start();
require('database.php');

// Redirect to login if not authenticated
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Only handle POST requests for removing a friend
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $friend_username = trim($_POST['friend_username'] ?? '');
    $current_username = $_SESSION['username'];

    // If no friend username provided, redirect back
    if (empty($friend_username)) {
        header("Location: friend.php");
        exit;
    }

    // Get current user ID
    $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $current_username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $user_id);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    // Get friend's user ID
    $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $friend_username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $friend_id);
    $found = mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if ($found) {
        // Remove friendship both ways from user_friends table
        mysqli_query($conn, "DELETE FROM user_friends 
                           WHERE (user_id = $user_id AND friend_id = $friend_id) 
                           OR (user_id = $friend_id AND friend_id = $user_id)");
        
        // Remove any pending friend requests between the two users
        mysqli_query($conn, "DELETE FROM friend_requests 
                           WHERE (from_user_id = $user_id AND to_user_id = $friend_id)
                           OR (from_user_id = $friend_id AND to_user_id = $user_id)");
    }

    // Redirect back to friends page
    header("Location: friend.php");
    exit;
}

// If not POST request, redirect to friends page
header("Location: friend.php");
exit;
?>
