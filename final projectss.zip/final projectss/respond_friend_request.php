<?php
// respond_friend_request.php
// Handles accepting or denying a friend request for the logged-in user.

session_start();
require('database.php');

// Redirect to login if not authenticated
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $from_username = $_POST['from_user'] ?? '';
    $action = $_POST['action'] ?? '';
    $to_username = $_SESSION['username'];

    // Get IDs for both users
    $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $to_username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $to_user_id);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $from_username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $from_user_id);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if ($action === "accept") {
        // Accept the friend request
        $stmt = mysqli_prepare($conn, "UPDATE friend_requests SET status = 'accepted' WHERE from_user_id = ? AND to_user_id = ? AND status = 'pending'");
        mysqli_stmt_bind_param($stmt, "ii", $from_user_id, $to_user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Add both users as friends (both directions)
        mysqli_query($conn, "INSERT IGNORE INTO user_friends (user_id, friend_id) VALUES ($from_user_id, $to_user_id), ($to_user_id, $from_user_id)");
    } elseif ($action === "deny") {
        // Deny the friend request
        $stmt = mysqli_prepare($conn, "UPDATE friend_requests SET status = 'denied' WHERE from_user_id = ? AND to_user_id = ? AND status = 'pending'");
        mysqli_stmt_bind_param($stmt, "ii", $from_user_id, $to_user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
    // Redirect back to friends page
    header("Location: friend.php");
    exit;
}
?>
